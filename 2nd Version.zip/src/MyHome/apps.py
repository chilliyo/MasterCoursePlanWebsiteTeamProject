from django.apps import AppConfig


class MyhomeConfig(AppConfig):
    name = 'MyHome'
